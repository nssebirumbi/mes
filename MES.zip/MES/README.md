<h2>What is needed in the MES App</h2>

<p>
    Users login, then courses are listed say:
    ->Civil, Electrical, Computer Engineering, Mechanical, Teleccome Engineering.
    -> When a course is chosen, display the years, say:: Year 1, year2, year 3, year 4.
    ->When a year is checked, the view the semesters, say sem 1 year 1, etc.
    ->when the semesters are checked, Choose if Hand outs, past papers, text books,  for that course you selected.

    Users can see some info. such info includes a sample vid in the background showing you what happend in the previous site, but to use the app, they must first log in.

    News and Activities:: like feeds.
    -> Internship places,
    -> Advertise for schollar ships.
    -> Soccer Adverts.
    ->Mes Afternoons mentoring.
</p>
