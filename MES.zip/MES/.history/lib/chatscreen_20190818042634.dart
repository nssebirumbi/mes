import 'package:flutter/material.dart';
import 'package:mesapp/apiservices.dart';
import 'package:mesapp/login.dart';
import 'chatmessage.dart';

class ChatScreen extends StatefulWidget {
  @override
  State createState() => new ChatScreenState();
}

class ChatScreenState extends State<ChatScreen> {
  bool _isLoading = false;
  final TextEditingController _textController = new TextEditingController();
  final List<ChatMessage> _messages = <ChatMessage>[];

  void _handleSubmitted(String text) {
    if(text.isEmpty){

    }else{
      final post = {
        'message': _textController.text,
        'user_id': userId
      };

      ApiServices.addPost(post).then((success){
        
        String title, text;
        if (success){
          
          
        }else{
          
        }
      });
      _textController.clear();
      ChatMessage message = new ChatMessage(
        text: text,
      );
      setState(() {
        _messages.insert(0, message);
      });
    }
    
  }

  Widget _textComposerWidget() {
    return new IconTheme(
      data: new IconThemeData(color: Colors.blue),
      child: new Container(
        margin: const EdgeInsets.symmetric(horizontal: 8.0),
        child: new Row(
          children: <Widget>[
            Expanded(
              child: Container(
                // child: new Flexible(
                  child: new TextField(
                    decoration:
                    new InputDecoration.collapsed(hintText: "Send a message"),
                    controller: _textController,
                    onSubmitted: _handleSubmitted,
                  ),
                // ),
              ),
            ),
            new Container(
              margin: const EdgeInsets.symmetric(horizontal: 4.0),
              child: new IconButton(
                icon: new Icon(Icons.send),
                onPressed: () => _handleSubmitted(_textController.text),
              ),
            )
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("asset/images/backgroung.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: new Column(
          children: <Widget>[
            // FutureBuilder(
            //   future: ApiServices.getPosts(),
            //   builder: (context, snapshot) {
            //     if (snapshot.connectionState == ConnectionState.done) {
            //       final posts = snapshot.data;
            //       new Flexible(
            //         child: new ListView.builder(
            //           padding: new EdgeInsets.all(8.0),
            //           reverse: true,
            //           itemBuilder: (_, int index) => _messages[index],
            //           itemCount: posts.length,
            //         ),
            //       );
            //     }
            //   }
            // ),
            new Flexible(
              child: new ListView.builder(
                padding: new EdgeInsets.all(8.0),
                reverse: true,
                itemBuilder: (_, int index) => _messages[index],
                itemCount: _messages.length,
              ),
            ),
          new Divider(
            height: 1.0,
          ),
          new Container(
            decoration: new BoxDecoration(
              color: Theme.of(context).cardColor,
            ),
            child: _textComposerWidget(),
          ),
        ],
      ),
    );
  }
}
