// //add import statements to import necessary packages
// import 'dart:async';
// import 'dart:convert';

// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;

// class SingleNews extends StatelessWidget {
//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: new AppBar(
//           title: Text('Quote of the Day'),
//         ),
//         body: Center(
//           child: FutureBuilder<Quote>(
//             future: getQuote(), //sets the getQuote method as the expected Future
//             builder: (context, snapshot) {
//               if (snapshot.hasData) { //checks if the response returns valid data              
//                 return Center(
//                   child: Column(
//                     children: <Widget>[
//                       Text(snapshot.data.quote), //displays the quote
//                       SizedBox(
//                         height: 10.0,
//                       ),
//                       Text(" - ${snapshot.data.author}"), //displays the quote's author
//                     ],
//                   ),
//                 );
//               } else if (snapshot.hasError) { //checks if the response throws an error
//                 return Text("${snapshot.error}");
//               }
//               return CircularProgressIndicator();
//             },
//           ),
//         ),
//       );
//   }

//   Future<Quote> getQuote() async {
//     String url = 'https://quotes.rest/qod.json';
//     final response =
//         await http.get(url, headers: {"Accept": "application/json"});


//     if (response.statusCode == 200) {
//       return Quote.fromJson(json.decode(response.body));
//     } else {
//       throw Exception('Failed to load post');
//     }
//   }
// }



// class Quote {
//   final String author;
//   final String quote;

//   Quote({this.author, this.quote});

//   factory Quote.fromJson(Map<String, dynamic> json) {
//     return Quote(
//         author: json['contents']['quotes'][0]['author'],
//         quote: json['contents']['quotes'][0]['quote']);
//   }
// }

import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

Future<News> fetchNews() async {
  final response =
      await http.get('http://app.mes.mubali.net/api/types/3/news/260');

  if (response.statusCode == 200) {
    // If the call to the server was successful, parse the JSON.
    return News.fromJson(json.decode(response.body));
  } else {
    // If that call was not successful, throw an error.
    throw Exception('Failed to load News');
  }
}

class News {
  final String title;
  final String pic;
  final String body;

  News({this.title, this.pic, this.body});

  factory News.fromJson(Map<String, dynamic> json) {
    return News(
      pic: json[''],
      title: json['headline'],
      body: json['details'],
    );
  }
}


class SingleNews extends StatelessWidget {
  final Future<News> news;

  SingleNews({Key key, this.news}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
        ),

        body: Container(
          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.all(10.0),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              Colors.white,
              Colors.white24,
            ]),
          ),
          
          child: FutureBuilder<News>(
            future: news,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return Center(
                  child: Column(
                    children: <Widget>[
                      Hero(
                        tag: 'hero',
                        child: Padding(
                          padding: EdgeInsets.all(5.0),
                          child: new Image(
                            image: AssetImage('images/politics.jpg')
                          )
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text(
                          snapshot.data.title,
                          style: TextStyle(fontSize: 28.0, color: Colors.black87),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text(
                          snapshot.data.body,
                          style: TextStyle(fontSize: 16.0, color: Colors.black),
                          textAlign: TextAlign.justify,
                        ),
                      ),
                    ],
                  ),
                );
                
              } else if (snapshot.hasError) {
                return Text("${snapshot.error}");
              }

              // By default, show a loading spinner.
              return CircularProgressIndicator();
            },
          ),
        ),
    );
  }
}
