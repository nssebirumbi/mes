import 'package:flutter/material.dart';
import 'package:mesapp/apiservices.dart';


import 'singlenews.dart';

class NewsTabs extends StatefulWidget {

  NewsTabs(this.colorVal);
  int colorVal;

  _NewsTabsState createState() => _NewsTabsState();
}

class _NewsTabsState extends State<NewsTabs> with SingleTickerProviderStateMixin{
TabController _tabController;

@override
    void initState() {
      super.initState();
      _tabController = new TabController(vsync: this, length: 4);
      _tabController.addListener(_handleTabSelection);
    }
    void _handleTabSelection() {
        setState(() {
          widget.colorVal=0xffff5722;
        });
    }
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length:4,
      child: Scaffold(
        appBar: new PreferredSize(
          preferredSize: Size.fromHeight(kToolbarHeight),
          child: new Container(
            child: new SafeArea(
              child: Column(
                children: <Widget>[
                  new Expanded(child: new Container()),
                  new TabBar(
                    isScrollable: true,
                    controller: _tabController,
                    labelPadding: EdgeInsets.all(10.0),
                    indicatorColor: Color(widget.colorVal),
                    indicatorWeight: 4.0,
                    tabs: [
                      Text("Mentorship",
                          style: TextStyle(
                              color: _tabController.index == 0
                                  ? Color(widget.colorVal)
                                  : Colors.black)),
                      Text("Scholarship",
                          style: TextStyle(
                              color: _tabController.index == 1
                                  ? Color(widget.colorVal)
                                  : Colors.black)),
                      Text("Soccer",
                          style: TextStyle(
                              color: _tabController.index == 2
                                  ? Color(widget.colorVal)
                                  : Colors.black)),
                      Text("Internship",
                          style: TextStyle(
                              color: _tabController.index == 3
                                  ? Color(widget.colorVal)
                                  : Colors.black)),
            
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          
            children: <Widget>[
              FutureBuilder(
                future: ApiServices.getNewsList(),
                builder: (context, snapshort){
                  if(snapshort.connectionState == ConnectionState.done){
                    final news = snapshort.data;
                    return ListView.separated(
                      separatorBuilder: (context, index){
                        return Divider(height: 2, color: Colors.black,);
                      },
                      itemBuilder: (context, index){
                        return ListTile(
                          title: Text(
                            news[index]['headline'],
                            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                             news[index]['details'] 
                          )
                        )
                      },
                    )
                  }else{

                  }
                },
              )
            ],
            /*
            End of the Soccer Widget
            */
        ),
      ),
    );
  }
}