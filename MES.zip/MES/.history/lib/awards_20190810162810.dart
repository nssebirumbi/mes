import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'profile.dart';


class Awards extends StatefulWidget {
   int colorVal;
  Awards(this.colorVal);
  _AwardsState createState() => _AwardsState();
}

class _AwardsState extends State<Awards> with SingleTickerProviderStateMixin{
  TabController _tabController;

  @override
     void initState() {
       super.initState();
     }
     void _handleTabSelection() {
        setState(() {
          widget.colorVal=0xff2196f3;
         });
     }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: new Container(
          child: ListView(
            padding: EdgeInsets.only(left: 10.0, top: 5.0, right: 10.0),
            children: <Widget>[
              ListView(
              padding: EdgeInsets.only(left: 10.0, top: 5.0, right: 10.0),
              children: <Widget>[
                  new ListTile(
                      
                      leading: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTap: () {
                        Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                      },
                      child: Container(
                        width: 130,
                        height: 130,
                        padding: EdgeInsets.symmetric(vertical: 4.0),
                        alignment: Alignment.center,
                        child: new Image.asset(
                          'images/Cedat.jpg',
                          width: 130.0, 
                          height: 130.0,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    title: Text('Ministry Of Sports and Education Releases a list On Intern Winners'),
                    dense: false,

                    onTap: () {
                      Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                    }
                  ),
                  new ListTile(
                      
                      leading: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTap: () {
                        Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                      },
                      child: Container(
                        width: 130,
                        height: 130,
                        padding: EdgeInsets.symmetric(vertical: 4.0),
                        alignment: Alignment.center,
                        child: new Image.asset(
                          'images/Cedat.jpg',
                          width: 130.0, 
                          height: 130.0,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    title: Text('Ministry Of Sports and Education Releases a list On Intern Winners'),
                    dense: false,

                    onTap: () {
                      Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                    }
                  ),
                  new ListTile(
                      
                      leading: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTap: () {
                        Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                      },
                      child: Container(
                        width: 130,
                        height: 130,
                        padding: EdgeInsets.symmetric(vertical: 4.0),
                        alignment: Alignment.center,
                        child: new Image.asset(
                          'images/Cedat.jpg',
                          width: 130.0, 
                          height: 130.0,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    title: Text('Ministry Of Sports and Education Releases a list On Intern Winners'),
                    dense: false,

                    onTap: () {
                      Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                    }
                  ),
                  new ListTile(
                      
                      leading: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTap: () {
                        Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                      },
                      child: Container(
                        width: 130,
                        height: 130,
                        padding: EdgeInsets.symmetric(vertical: 4.0),
                        alignment: Alignment.center,
                        child: new Image.asset(
                          'images/Cedat.jpg',
                          width: 130.0, 
                          height: 130.0,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    title: Text('Ministry Of Sports and Education Releases a list On Intern Winners'),
                    dense: false,

                    onTap: () {
                      Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                    }
                  ),
                  new ListTile(
                      
                      leading: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTap: () {
                        Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                      },
                      child: Container(
                        width: 130,
                        height: 130,
                        padding: EdgeInsets.symmetric(vertical: 4.0),
                        alignment: Alignment.center,
                        child: new Image.asset(
                          'images/Cedat.jpg',
                          width: 130.0, 
                          height: 130.0,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    title: Text('Ministry Of Sports and Education Releases a list On Intern Winners'),
                    dense: false,

                    onTap: () {
                      Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                    }
                  ),
                  new ListTile(
                      
                      leading: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTap: () {
                        Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                      },
                      child: Container(
                        width: 130,
                        height: 130,
                        padding: EdgeInsets.symmetric(vertical: 4.0),
                        alignment: Alignment.center,
                        child: new Image.asset(
                          'images/Cedat.jpg',
                          width: 130.0, 
                          height: 130.0,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    title: Text('Ministry Of Sports and Education Releases a list On Intern Winners'),
                    dense: false,

                    onTap: () {
                      Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                    }
                  ),
                  new ListTile(
                      
                      leading: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTap: () {
                        Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                      },
                      child: Container(
                        width: 130,
                        height: 130,
                        padding: EdgeInsets.symmetric(vertical: 4.0),
                        alignment: Alignment.center,
                        child: new Image.asset(
                          'images/Cedat.jpg',
                          width: 130.0, 
                          height: 130.0,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    title: Text('Ministry Of Sports and Education Releases a list On Intern Winners'),
                    dense: false,

                    onTap: () {
                      Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                    }
                  ),
                  new Divider(),
                  new ListTile(
                      
                      leading: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTap: () {
                        Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                      },
                      child: Container(
                        width: 130,
                        height: 130,
                        padding: EdgeInsets.symmetric(vertical: 4.0),
                        alignment: Alignment.center,
                        child: new Image.asset(
                          'images/Cedat.jpg',
                          width: 130.0, 
                          height: 130.0,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    title: Text('Ministry Of Sports and Education Releases a list On Intern Winners'),
                    dense: false,

                    onTap: () {
                      Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new Profile()));
                    }
                  ),
                ]
              ),
            ],
          ),
        ),
    );
  }
}

class universityImages extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    AssetImage assetImage = AssetImage('images/Cedat.jpg');
    Image image = Image(image: assetImage, width: 130.0, height: 100.0,);
    return Container(child: image,);
  }
}
class cranesImage extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    AssetImage assetImage = AssetImage('images/cranes.jpg');
    Image image = Image(image: assetImage, width: 130.0, height: 100.0,);
    return Container(child: image,);
  }
}
class ministryOfSports extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    AssetImage assetImage = AssetImage('images/Interns.png');
    Image image = Image(image: assetImage, width: 130.0, height: 100.0,);
    return Container(child: image,);
  }
}
class scholarship extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    AssetImage assetImage = AssetImage('images/Scholarship.jpg');
    Image image = Image(image: assetImage, width: 140.0, height: 100.0,);
    return Container(child: image,);
  }
}

class mentorship extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    AssetImage assetImage = AssetImage('images/mentorship.jpg');
    Image image = Image(image: assetImage, width: 140.0, height: 100.0,);
    return Container(child: image);
  }
}
class politics extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    AssetImage assetImage = AssetImage('images/politics.jpg');
    Image image = Image(image: assetImage, width: 140.0, height:100.0,);
    return Container(child: image,);
  }
}