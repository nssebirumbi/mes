import 'package:flutter/material.dart';
import 'package:mesapp/apiservices.dart';
import 'package:mesapp/signup.dart';
import 'package:mesapp/news.dart';
class LoginPage extends StatefulWidget {
  static String tag = 'login-page';
  @override
  _LoginPageState createState() => new _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  TextEditingController _usernameController = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    /**
     * Back-ground Image for the Login Page But has Miss Behaved for now
     */
    // return Scaffold(
    //   body: Container(
    //     decoration: BoxDecoration(
    //       image: DecorationImage(
    //         image: AssetImage("assets/images/bulb.jpg"),
    //         fit: BoxFit.cover,
    //       ),
    //     ),
    //     child: null /* add child content here */,
    //   ),
    // );
    final logo = Hero(
      tag: 'hero',
      child: CircleAvatar(
        backgroundColor: Colors.transparent,
        radius: 72.0,
        child: Image.asset('images/logo.png'),
      ),
    );

    final email = TextFormField(
      keyboardType: TextInputType.emailAddress,
      autofocus: false,
      initialValue: 'julisema4@gmail.com',
      decoration: InputDecoration(
        hintText: 'Email',
        contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.0)),
      ),
      controller: _usernameController,
    );

    final password = TextFormField(
      autofocus: false,
      initialValue: 'paswordAdmin',
      obscureText: true,
      decoration: InputDecoration(
        hintText: 'Password',
        contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.0)),
      ),
    );

    final loginButton = Padding(
      padding: EdgeInsets.symmetric(vertical: 16.0),
      child: RaisedButton(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        onPressed: () async {
          final users = await ApiServices.getUserList();
          // if(users == null){

          // }else{
          //   users.any((u)=> u['username']== _usernameController.text)
          // }


          // setState(() {
          //   _isLoading = true;
          // });
          // final users = await ApiService.getUserList();
          // setState(() {
          //   _isLoading = false;
          // });
          if (users == null) {
            showDialog(
              context: context,
              builder: (context) {
                return AlertDialog(
                  title: Text('Error'),
                  content: Text("Check your internet connection"),
                  actions: <Widget>[
                    FlatButton(
                      child: Text('Ok'),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    )
                  ],
                );
              }
            );
            return;
          } else {
            final userWithUsernameExists = users.any((u) => u['username'] == _usernameController.text);
            if (userWithUsernameExists) {
              Navigator.push(
                context,
                MaterialPageRoute(
                  //builder: (context) => Posts()
                )
              );
            } else {
              showDialog(
                context: context,
                builder: (context) {
                  return AlertDialog(
                    title: Text('Incorrect username'),
                    content: Text('Try with a different username'),
                    actions: <Widget>[
                      FlatButton(
                        child: Text('Ok'),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                      )
                    ],
                  );
                }
              );
            }
          }

          // Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new HomePage()));
        },
        padding: EdgeInsets.all(12),
        color: Colors.lightBlueAccent,
        child: Text('Log In', style: TextStyle(color: Colors.white)),
      ),
    );

    final forgotLabel = FlatButton(
      child: Text(
        'Create Account?',
        style: TextStyle(color: Colors.black54),
      ),
      onPressed: () {
        Navigator.of(context).push(new MaterialPageRoute(builder: (BuildContext context) => new SignUp()));
      },
    );

    final body = Container(
      width: MediaQuery.of(context).size.width,
      //padding: EdgeInsets.all(10.0),
      padding: EdgeInsets.fromLTRB(20.0, 50.0, 20.0, 10.0),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          Colors.white,
          Colors.white24,
        ]),
      ),
      child: Column(
        children: <Widget>[
          logo,
          SizedBox(height: 48.0),
          TextField(
              decoration: InputDecoration(
                hintText: 'Username'
              ),
              controller: _usernameController,
          ),
          SizedBox(height: 18.0),
          password,
          SizedBox(height: 24.0),
          loginButton,
          forgotLabel
        ],
      ),
    );

    return Scaffold(
      //backgroundColor: Colors.white, //#00c9b7
      backgroundColor: Color.fromRGBO(100, 255, 255, 0.4),
      body: body,
      // body: Center(
      //   child: ListView(
      //     shrinkWrap: true,
      //     padding: EdgeInsets.only(left: 24.0, right: 24.0),
      //     children: <Widget>[
      //       logo,
      //       SizedBox(height: 48.0),
      //       email,
      //       SizedBox(height: 18.0),
      //       password,
      //       SizedBox(height: 24.0),
      //       loginButton,
      //       forgotLabel
      //     ],
      //   ),
      // ),
    );
  }
}


class User {
  final String name;
  final String email;

  User(this.name, this.email);

  User.fromJson(Map<String, dynamic> json)
      : name = json['name'],
        email = json['email'];

  Map<String, dynamic> toJson() =>
    {
      'name': name,
      'email': email,
    };
}
