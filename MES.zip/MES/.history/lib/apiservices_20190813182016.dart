import 'dart:convert';

import 'package:http/http.dart' as http;

class ApiServices{
  static Future<List<dynamic>> getUserList() async {
    final response = await http.get('${Urls.BASE_URL}/users');
    if (response.statusCode == 200){
      return json.decode(response.body);
    }else{
      return null;
    }
  }
}


class Urls{
  static const BASE_URL = "http://127.0.0.1:8000/api/";
}