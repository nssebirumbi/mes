import 'package:http/http.dart' as http;

class ApiServices{
  static List<dynamic> getUserList(){
    final response = http.get(url)
  }
}


class Urls{
  static const BASE_URL = "http://127.0.0.1:8000";
}