// import 'dart:io';

// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:flutter_pdfview/flutter_pdfview.dart';
// import 'package:http/http.dart' as http;

// class Material extends StatefulWidget {
//   @override
//   _MaterialState createState() => _MaterialState();
// }

// class _MaterialState extends State<Material> {
  

//   // @override
//   // Widget build(BuildContext context) {
//   //   return MaterialApp(
//   //     debugShowCheckedModeBanner: false,
//   //     home: Scaffold(
//   //       appBar: AppBar(
//   //         title: Text("Flutter PDF Tutorial"),
//   //       ),
//   //       body: Center(
//   //         child: Builder(
//   //           builder: (context) => Column(
//   //                 mainAxisAlignment: MainAxisAlignment.center,
//   //                 children: <Widget>[
//   //                   RaisedButton(
//   //                     color: Colors.amber,
//   //                     child: Text("Open from URL"),
//   //                     onPressed: () {
//   //                       if (urlPDFPath != null) {
//   //                         Navigator.push(
//   //                             context,
//   //                             MaterialPageRoute(
//   //                                 builder: (context) =>
//   //                                     PdfViewPage(path: assetPDFPath)));
//   //                       }
//   //                     },
//   //                   ),
//   //                   SizedBox(
//   //                     height: 20,
//   //                   ),
//   //                   RaisedButton(
//   //                     color: Colors.cyan,
//   //                     child: Text("Open from Asset"),
//   //                     onPressed: () {
//   //                       if (assetPDFPath != null) {
//   //                         Navigator.push(
//   //                             context,
//   //                             MaterialPageRoute(
//   //                                 builder: (context) =>
//   //                                     PdfViewPage(path: assetPDFPath)));
//   //                       }
//   //                     },
//   //                   )
//   //                 ],
//   //               ),
//   //         ),
//   //       ),
//   //     ),
//   //   );
//   // }
// }

