import 'package:flutter/material.dart';

class Material extends StatefulWidget {
  final String title;
  @override
  _MaterialState createState() => _MaterialState();
}

class _MaterialState extends State<Material> {

  int _counter =0;
  @override
  Widget build(BuildContext context) {
    return Center(
      
    ),
    FloatingActionButton: FloatingActionButton(
      onPressed: _incrementCounter,
      tooltip: 'Increment',
      child: Icon(Icons.note),
    );
  }

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }
}