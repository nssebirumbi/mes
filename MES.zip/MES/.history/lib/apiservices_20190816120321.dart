import 'dart:convert';

import 'login.dart';
import 'package:http/http.dart' as http;

class ApiServices {
  static Future<List<dynamic>> getUserList() async {
    try {
      final response = await http.get('${Urls.BASE_URL}/users');
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        return null;
      }
    } catch (ex) {
      return null;
    }
  }

  static Future<List<dynamic>> getNewsList() async {
    try {
      final response = await http.get('${Urls.BASE_URL}/types/3/news');
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        return null;
      }
    } catch (ex) {
      return null;
    }
  }



  static Future<dynamic> _get(String url) async {
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        return null;
      }
    } catch (ex) {
      return null;
    }
  }

  static Future<List<dynamic>> getUserList() async {
    return await _get('${Urls.BASE_URL}/users');
  }

  static Future<List<dynamic>> getPostList() async {
    return await _get('${Urls.BASE_URL}/posts');
  }

  static Future<dynamic> getPost(int postId) async {
    return await _get('${Urls.BASE_URL}/posts/$postId');
  }

  static Future<dynamic> getCommentsForPost(int postId) async {
    return await _get('${Urls.BASE_URL}/posts/$postId/comments');
  }
}
