import 'package:flutter/material.dart';
import 'package:flutter_full_pdf_viewer/flutter_full_pdf_viewer.dart';
import 'package:flutter_full_pdf_viewer/full_pdf_viewer_plugin.dart';
import 'package:flutter_full_pdf_viewer/full_pdf_viewer_scaffold.dart';

class Material extends StatefulWidget {
  //final String title;
  @override
  _MaterialState createState() => _MaterialState();
}

class _MaterialState extends State<Material> {

  int _counter =0;
  bool _isLoading = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: _isLoading? Center(
          child: CircularProgressIndicator(),
        ): PDFViewer(document: null)
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: Icon(Icons.note),
      )
    );
  }

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }
}