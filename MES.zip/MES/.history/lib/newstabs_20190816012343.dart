import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:mesapp/apiservices.dart';


import 'singlenews.dart';

class NewsTabs extends StatefulWidget {

  NewsTabs(this.colorVal);
  int colorVal;

  _NewsTabsState createState() => _NewsTabsState();
}

class _NewsTabsState extends State<NewsTabs> with SingleTickerProviderStateMixin{
TabController _tabController;

Future<Post> post;

@override
    void initState() {
      super.initState();
      _tabController = new TabController(vsync: this, length: 4);
      _tabController.addListener(_handleTabSelection);
      post = fetchPost();
    }
    void _handleTabSelection() {
        setState(() {
          widget.colorVal=0xffff5722;
        });
    }
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length:4,
      child: Scaffold(
        appBar: new PreferredSize(
          preferredSize: Size.fromHeight(kToolbarHeight),
          child: new Container(
            child: new SafeArea(
              child: Column(
                children: <Widget>[
                  new Expanded(child: new Container()),
                  new TabBar(
                    isScrollable: true,
                    controller: _tabController,
                    labelPadding: EdgeInsets.all(10.0),
                    indicatorColor: Color(widget.colorVal),
                    indicatorWeight: 4.0,
                    tabs: [
                      Text("Mentorship",
                          style: TextStyle(
                              color: _tabController.index == 0
                                  ? Color(widget.colorVal)
                                  : Colors.black)),
                      Text("Scholarship",
                          style: TextStyle(
                              color: _tabController.index == 1
                                  ? Color(widget.colorVal)
                                  : Colors.black)),
                      Text("Soccer",
                          style: TextStyle(
                              color: _tabController.index == 2
                                  ? Color(widget.colorVal)
                                  : Colors.black)),
                      Text("Internship",
                          style: TextStyle(
                              color: _tabController.index == 3
                                  ? Color(widget.colorVal)
                                  : Colors.black)),
            
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          
            children: <Widget>[
              FutureBuilder(
                future: ApiServices.getNewsList(),
                builder: (context, snapshort){
                  if (snapshot.hasData) {
                    return ListView.separated(
                      separatorBuilder: (context, index){
                        return Divider(height: 2, color: Colors.black,);
                      },
                      itemBuilder: (context, index){
                        return ListTile(
                          title: Text(
                            snapshot.data.title,
                            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                             news[index]['details'] 
                          )
                        );
                      },
                      itemCount: news.length,
                    );
                  } else if (snapshot.hasError) {
                    return Text("${snapshot.error}");
                  }
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                },
              ),
              FutureBuilder(
                future: ApiServices.getNewsList(),
                builder: (context, snapshort){
                  if(snapshort.connectionState == ConnectionState.done){
                    final news = snapshort.data;
                    return ListView.separated(
                      separatorBuilder: (context, index){
                        return Divider(height: 2, color: Colors.black,);
                      },
                      itemBuilder: (context, index){
                        return ListTile(
                          title: Text(
                            news[index]['headline'],
                            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                             news[index]['details'] 
                          )
                        );
                      },
                      itemCount: news.length,
                    );
                  }
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                },
              ),
              FutureBuilder(
                future: ApiServices.getNewsList(),
                builder: (context, snapshort){
                  if(snapshort.connectionState == ConnectionState.done){
                    final news = snapshort.data;
                    return ListView.separated(
                      separatorBuilder: (context, index){
                        return Divider(height: 2, color: Colors.black,);
                      },
                      itemBuilder: (context, index){
                        return ListTile(
                          title: Text(
                            news[index]['headline'],
                            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                             news[index]['details'] 
                          )
                        );
                      },
                      itemCount: news.length,
                    );
                  }
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                },
              ),
              FutureBuilder(
                future: ApiServices.getNewsList(),
                builder: (context, snapshort){
                  if(snapshort.connectionState == ConnectionState.done){
                    final news = snapshort.data;
                    return ListView.separated(
                      separatorBuilder: (context, index){
                        return Divider(height: 2, color: Colors.black,);
                      },
                      itemBuilder: (context, index){
                        return ListTile(
                          title: Text(
                            news[index]['headline'],
                            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                          ),
                          subtitle: Text(
                             news[index]['details'] 
                          )
                        );
                      },
                      itemCount: news.length,
                    );
                  }
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                },
              )
            ],
            /*
            End of the Soccer Widget
            */
        ),
      ),
    );
  }
}


Future<Post> fetchPost() async {
  final response =
      await http.get('http://app.mes.mubali.net/api/types/3/news/259');

  if (response.statusCode == 200) {
    // If the call to the server was successful, parse the JSON.
    return Post.fromJson(json.decode(response.body));
  } else {
    // If that call was not successful, throw an error.
    throw Exception('Failed to load post');
  }
}

class Post {
  final String title;
  final String body;

  Post({this.title, this.body});

  factory Post.fromJson(Map<String, dynamic> json) {
    return Post(
      
      title: json['headline'],
      body: json['details'],
    );
  }
}