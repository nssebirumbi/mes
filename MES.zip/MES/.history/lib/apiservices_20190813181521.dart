import 'package:http/http.dart' as http;

class ApiServices{
  static List<dynamic> getUserList(){
    final response = await http.get('${Urls.BASE_URL}/users')
  }
}


class Urls{
  static const BASE_URL = "http://127.0.0.1:8000/api/";
}